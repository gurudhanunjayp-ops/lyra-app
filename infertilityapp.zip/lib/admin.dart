import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:infertilityapp/alogin.dart';
import 'package:infertilityapp/app_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'second_page.dart';
import 'comman.dart';
import 'dart:async';

class Admin extends StatefulWidget {
  @override
  _AdminState createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  final TextEditingController passwordController = TextEditingController();
  final String adminId = '1920';
  bool _isPasswordVisible = false;

  void _togglePasswordVisibility() {
    setState(() {
      _isPasswordVisible = !_isPasswordVisible;
    });

    // Automatically hide the password after 2 seconds
    Timer(Duration(seconds: 1), () {
      setState(() {
        _isPasswordVisible = false;
      });
    });
  }

  get userId => userId; // Admin ID constant

  Future<void> loginAdmin() async {
    var url = Uri.parse(doctorlogin);

    // Data to send via form data (not JSON)
    var data = {
      'dr_userid': adminId,
      'password': passwordController.text,
    };

    // Send POST request to the server
    var response = await http.post(
      url,
      body: data, // Sending as form data
    );

    // Clean up response body to remove extra text like "Connected"
    String responseBody = response.body;
    if (responseBody.contains("{")) {
      responseBody = responseBody.substring(responseBody.indexOf("{"));
    }

    try {
      // Parse the cleaned JSON response
      var responseData = jsonDecode(responseBody);

      // Check login status
      if (responseData['status'] == 'success') {
        // Save the User ID using shared preferences
        SharedPreferences prefs = await SharedPreferences.getInstance();
        // await prefs.setString('UserId', userIdController.text);

        // Navigate to the FifthPage
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ALogin(), // Replace this if needed
          ),
          // ),
        );
      } else {
        // Login failed
        _showLoginFailedDialog();
      }
    } catch (e) {
      // Handle the parsing error
      print('Error parsing JSON: $e');
      _showLoginFailedDialog();
    }
  }

  void _showLoginFailedDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Login Failed'),
          content: Text('Invalid user id or password'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        // Navigate to AdminPage when back button is pressed
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => SecondPage()),
        );
      },
      child: Scaffold(
        body: AppBackground(
          decor: BgDecor.crosses,
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                children: [
                  const SizedBox(height: 16),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      onPressed: () => Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => SecondPage()),
                      ),
                      icon: const Icon(Icons.arrow_back_ios_new_rounded,
                          color: AppColors.ink),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const GradientIconBadge(
                    icon: Icons.admin_panel_settings_outlined,
                    size: 92,
                    iconSize: 44,
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Admin Login',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      color: AppColors.ink,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Restricted access — administrators only',
                    style: TextStyle(fontSize: 14.5, color: AppColors.muted),
                  ),
                  const SizedBox(height: 30),
                  SectionCard(
                    child: Column(
                      children: [
                        AppTextField(
                          label: 'Admin ID',
                          icon: Icons.person_outline_rounded,
                          controller: TextEditingController(text: adminId),
                          enabled: false,
                        ),
                        const SizedBox(height: 18),
                        AppTextField(
                          label: 'Password',
                          hint: 'Enter admin password',
                          icon: Icons.lock_outline_rounded,
                          controller: passwordController,
                          obscureText: !_isPasswordVisible,
                          suffixIcon: IconButton(
                            icon: Icon(
                              _isPasswordVisible
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                            ),
                            onPressed: _togglePasswordVisibility,
                          ),
                        ),
                        const SizedBox(height: 26),
                        PrimaryButton(
                          label: 'Login',
                          icon: Icons.login_rounded,
                          onPressed: loginAdmin,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
