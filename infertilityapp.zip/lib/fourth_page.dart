import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:infertilityapp/app_ui.dart';
import 'package:infertilityapp/comman.dart';
import 'package:infertilityapp/plogin.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'forgot_password_page.dart';
import 'second_page.dart'; // Import the forgot password page

class FourthPage extends StatefulWidget {
  @override
  _FourthPageState createState() => _FourthPageState();
}

class _FourthPageState extends State<FourthPage> {
  TextEditingController userIdController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool _isPasswordVisible = false;
  bool _isLoading = false;

  void _togglePasswordVisibility() {
    setState(() {
      _isPasswordVisible = !_isPasswordVisible;
    });
    // Automatically hide the password after 2 seconds
    Timer(Duration(seconds: 1), () {
      setState(() {
        _isPasswordVisible = false;
      });
    });
  }

  Future<void> _login() async {
    setState(() => _isLoading = true);
    try {
      // API endpoint URL
      var url = Uri.parse(patientlogin);

      // Form data to be sent to the server
      var data = {
        'Userid': userIdController.text,
        'password': passwordController.text,
      };

      // Send POST request to the server
      var response = await http.post(
        url,
        body: data,
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      );

      // Print the raw response body
      print('Response body: ${response.body}');

      try {
        // Remove any unexpected text from the response
        String responseBody = response.body;
        if (responseBody.startsWith('Connected')) {
          responseBody = responseBody.substring('Connected'.length);
        }

        // Parse the response JSON
        var responseData = json.decode(responseBody);

        // Check login status
        if (responseData['status'] == 'success') {
          // Login successful
          // Save the User ID using shared preferences
          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString('userId', userIdController.text);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  PLoginPage(userId: userIdController.text, name: ''),
            ),
          );
        } else {
          // Login failed
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text('Login Failed'),
                content: Text('Invalid user id or password'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text('OK'),
                  ),
                ],
              );
            },
          );
        }
      } catch (e) {
        print('Error parsing response: $e');
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Error'),
              content:
                  Text('An error occurred while processing the response.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      }
    } catch (e) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Unable to reach the server. Please try again.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        // Navigate to the login page when the back button is pressed
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => SecondPage()),
          ModalRoute.withName('/'),
        );
      },
      child: Scaffold(
        body: AppBackground(
          decor: BgDecor.waves,
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                children: [
                  const SizedBox(height: 16),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      onPressed: () => Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => SecondPage()),
                      ),
                      icon: const Icon(Icons.arrow_back_ios_new_rounded,
                          color: AppColors.ink),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const GradientIconBadge(
                    icon: Icons.person_outline_rounded,
                    size: 92,
                    iconSize: 44,
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Patient Login',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      color: AppColors.ink,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Welcome back to your journey',
                    style: TextStyle(fontSize: 14.5, color: AppColors.muted),
                  ),
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.85),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withValues(alpha: 0.12),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        AppTextField(
                          label: 'User ID',
                          hint: 'Enter your user id',
                          icon: Icons.person_outline_rounded,
                          controller: userIdController,
                        ),
                        const SizedBox(height: 18),
                        AppTextField(
                          label: 'Password',
                          hint: 'Enter your password',
                          icon: Icons.lock_outline_rounded,
                          controller: passwordController,
                          obscureText: !_isPasswordVisible,
                          suffixIcon: IconButton(
                            icon: Icon(
                              _isPasswordVisible
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                            ),
                            onPressed: _togglePasswordVisibility,
                          ),
                        ),
                        const SizedBox(height: 26),
                        _isLoading
                            ? const CircularProgressIndicator(
                                color: AppColors.primary)
                            : PrimaryButton(
                                label: 'Login',
                                icon: Icons.login_rounded,
                                onPressed: _login,
                              ),
                        const SizedBox(height: 8),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ForgotPasswordPage()),
                            );
                          },
                          child: const Text('Create / Forgot Password?'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 36),
                  const Text(
                    'Hope blooms here.\nWelcome back to your journey',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
